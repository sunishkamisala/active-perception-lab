package com.bwc.ora.analysis;

public interface Analysis {

    public void run();
}
