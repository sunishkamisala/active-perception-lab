package com.bwc.ora.models.exception;

public class LRPBoundaryViolationException extends RuntimeException{
    public LRPBoundaryViolationException(String message) {
        super(message);
    }
}
