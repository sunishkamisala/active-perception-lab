package com.bwc.ora.analysis;

public class AnalysisConditionsNotMetException extends RuntimeException {
    public AnalysisConditionsNotMetException(String message) {
        super(message);
    }
}
