# ORA
OCT Reflectivity Analytics

This project is being developed by Brandon Wilk Consulting

## Packaging for Mac OS X
```
javapackager -deploy -v -native dmg -outdir target -outfile ora -srcfiles target/ORA-1.0.0.jar -appclass com.bwc.ora.Ora -name "ORA" -title "ORA"
```
